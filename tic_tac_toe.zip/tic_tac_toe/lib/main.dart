import 'package:flutter/material.dart';
import 'welcome_page.dart'; // Import the Welcome Page

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tic Tac Toe',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WelcomePage(), // Set WelcomePage as the home screen
    );
  }
}
