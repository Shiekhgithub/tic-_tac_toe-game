import 'package:flutter/material.dart';
import 'welcome_page.dart'; // Import the WelcomePage

class ResultsPage extends StatelessWidget {
  final String result;
  final Function resetGame;

  ResultsPage({required this.result, required this.resetGame});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Game Results'),
        centerTitle: true,
        backgroundColor: Colors.blueAccent, // Stylish app bar color
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.lightBlueAccent, Colors.blue],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(24.0), // Padding around the text
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9), // Semi-transparent background
                  borderRadius: BorderRadius.circular(12.0), // Rounded corners
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      offset: Offset(0, 4),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Text(
                  result,
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent, // Text color
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  resetGame(); // Reset the game when button is pressed
                  Navigator.pop(context); // Go back to Tic Tac Toe screen
                },
                child: Text('Play Again'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green, // Changed button color to green
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
              SizedBox(height: 10), // Added spacing between buttons
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => WelcomePage()), // Navigate to WelcomePage
                  );
                },
                child: Text('Exit'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent, // Color for Exit button
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
